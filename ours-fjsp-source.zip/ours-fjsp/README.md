# Ours 动态柔性作业车间调度

Ours 使用双部图网络为机器与就绪工序评分，通过精确联合匹配选择调度动作，并用 PPO 学习策略。机器与工序之间的双向图消息、学习得到的边评分和等待评分共同决定匹配；动作遵守机器资格、工序前序、作业到达和机器故障约束。

训练奖励为总拖期的负增量，完整回合的奖励和等于负总拖期。每次更新收集固定数量的联合决策，调度回合在自然结束后重置，更新边界不截断回合。策略可以选择不同派工数量，但存在可行派工时不选择完全空的匹配。

## 安装

需要 Python 3.9 或以上版本。依赖为 NumPy、PyTorch 和 PyYAML。

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

Windows 激活命令为 `.venv\Scripts\activate`。

## 训练

三个合成场景直接生成作业实例，不需要下载数据。

```bash
ours-train --config configs/S20L.yaml --output ../ours-runs/S20L
```

短程检查可覆盖训练预算参数：

```bash
ours-train --scenario S20L --updates 2 --rollout-steps 16 --output ../ours-runs/smoke
```

也可以使用模块入口：

```bash
python -m ours_fjsp.train --config configs/S40H.yaml --output ../ours-runs/S40H
```

| 场景 | 作业数 | 机器数 | 故障率参数 | 实例输入 |
| --- | ---: | ---: | ---: | --- |
| S20L | 20 | 10 | 0.01 | 随机生成 |
| S20H | 20 | 10 | 0.02 | 随机生成 |
| S40H | 40 | 10 | 0.02 | 随机生成 |
| Mk08 | 由算例确定 | 由算例确定 | 0.02 | 用户提供 |
| Mk09 | 由算例确定 | 由算例确定 | 0.02 | 用户提供 |

Mk08 和 Mk09 使用用户自备的 `.fjs` 或 JSON 算例，程序为其添加动态到达和机器故障属性：

```bash
ours-train --config configs/Mk08.yaml --instance /path/to/BrandimarteMk8.fjs --output ../ours-runs/Mk08
ours-train --config configs/Mk09.yaml --instance /path/to/BrandimarteMk9.fjs --output ../ours-runs/Mk09
```

默认预算为 300 次更新，每次 512 次联合决策。默认隐藏维度为 64，学习率为 0.0003，折扣因子为 1，GAE 参数为 0.95，PPO 截断系数为 0.2。每次更新执行 2 个优化 epoch，minibatch 大小为 64，价值缩放为 1000。精确匹配的机器子集动态规划支持至多 16 台机器。

训练输出保存在 `--output` 指定的目录，包含新训练的检查点和训练记录。示例将输出放在仓库目录之外。

## 推理

对自行训练的检查点执行确定性匹配：

```bash
ours-evaluate --checkpoint ../ours-runs/S20L/checkpoint.pt --scenario S20L --episodes 3
```

Mk 场景需要同时指定算例：

```bash
ours-evaluate --checkpoint ../ours-runs/Mk08/checkpoint.pt --scenario Mk08 --instance /path/to/BrandimarteMk8.fjs --episodes 3
```

推理指标默认打印到终端；需要保存时使用 `--output /path/to/evaluation.json`。

## 源码结构

```text
configs/                         五个场景的训练配置
src/ours_fjsp/algorithms/         图评分网络、精确匹配策略、PPO
src/ours_fjsp/envs/               调度环境与算例解析
src/ours_fjsp/scenarios.py        场景参数
src/ours_fjsp/runtime.py          事件推进与动作合法性检查
src/ours_fjsp/train.py            从零训练入口
src/ours_fjsp/evaluate.py         推理入口
tests/                           精确分布、动作约束和奖励恒等式检查
```

源码包只提供 Ours 的实现、配置和测试。预训练权重、实验结果、图表、第三方基线及原始公开算例不随包提供。

## 测试

```bash
python -m pip install -e '.[test]'
python -m pytest -p no:cacheprovider
```

## 上传 Git

从本目录创建或使用 Git 仓库，再连接自己的远程地址：

```bash
git init -b main
git add .
git commit -m "Add Ours FJSP implementation"
git remote add origin <your-repository-url>
git push -u origin main
```

`.gitignore` 排除了训练输出、权重、结果文件、算例、缓存和虚拟环境。
